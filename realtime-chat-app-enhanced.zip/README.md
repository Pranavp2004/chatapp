# Realtime Chat App (Enhanced)

A chat app using vector clocks, image upload support, and real-time messaging.

## 🚀 Features

- Realtime chat with message ordering
- Upload images (not just URLs)
- Sticker support, typing indicators
- Dark mode & responsive UI

## 🧪 How to Run Locally

```bash
git clone https://github.com/Pranavp2004/realtime-chat-app.git
cd realtime-chat-app
npm install
npm start
```

Then open [http://localhost:3000](http://localhost:3000)

## 🧾 To Upload an Image

Use the file input in the chat UI (code for UI not added yet - only backend ready)

---
